#include <iostream>
#include <cmath>
#include <math.h>

void punto(int vector1[], int vector2[], int tam, int *p);
void proyeccion(int vector2[], int pp, int *p, int tam);

using namespace std;
