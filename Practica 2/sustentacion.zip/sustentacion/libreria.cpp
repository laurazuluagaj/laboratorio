#include "libreria.h"

void punto(int vector1[], int vector2[], int tam, int *p){
    for(int i=0; i<tam; i++){
        *p+=(vector1[i]*vector2[i]);
    }
}
void proyeccion(int vector2[], int pp, int *p, int tam){
    float mag=0.0, numero;
    float proyec[tam]={};
    for(int i=0; i<tam; i++){
        mag+=pow(vector2[i], 2);
    }
    mag=sqrt(mag);
    numero=(pp/(pow(mag,2)));
    for(int i=0; i<tam; i++){
        proyec[i]=(vector2[i]*numero);
    }
    cout << "El producto punto de los dos vectores es: " << pp << endl;
    cout << "La proyeccion del vector 1 sobre el vector 2 es: [";
    for (int i=0; i<tam; i++){
        cout << proyec[i];
        if (i!=(tam-1)) cout << ",";
    }
    cout << "]" << endl;
}
