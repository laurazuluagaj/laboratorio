#include "libreria.h"

int main()
{
    int tam, pp=0;
    cout << "Ingrese la dimension de los vectores: ";
    cin >> tam;

    int vector1[tam]={}, vector2[tam]={}, proyec[tam]={};
    cout << "Ingrese valores del primer vector:" << endl;
    for( int i = 0; i < tam; i++ ) {
        cout << "[" << i << "]: ";
        cin >> vector1[i];
    }
    cout << "Ingrese valores del segundo vector:" << endl;
    for( int i = 0; i < tam; i++ ) {
        cout << "[" << i << "]: ";
        cin >> vector2[i];
    }
    punto(vector1, vector2, tam, &pp);
    proyeccion(vector2, pp, proyec, tam);
    return 0;
}
