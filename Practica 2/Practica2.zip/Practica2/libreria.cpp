#include "libreria.h"

void fun_a(int *px, int *py){
int tmp = *px;
*px = *py;
*py = tmp;
}
void fun_b(int a[], int tam){
int f, l;
int *b = a;
for (f = 0, l = tam -1; f < l; f++, l--) {
fun_a(&b[f], &b[l]);
}
}
void fun_c(double *a, int n, double *promedio, double *suma){
int i;
for (i = 0; i < n; i++) *suma += a[i];
*promedio = *suma / n;
}
bool fun_d(char cad1[], char cad2[], int tam){
    for(int i=0; i<tam;i++){
        if(cad1[i]!=cad2[i]) return false;
    }
    return true;
}
int fun_e(int cad[], int tam){
 int numero=0;
 for (int i=tam-1, p=1;i>=0;i--,p*=10){
     numero+=(cad[i]*p);
 }
 return numero;
}
void fun_f(int numero, int *p, int *tam){
    int num;
    for(int i=0;numero>0;i++,(*tam)++){
        num=numero%10;
        numero/=10;
        *(p+i)=num;
    }
    fun_b(p,*tam);
}
void fun_g(char cadena[], int tam){
    char cadena2[20]={}, letra, *p;
    bool resp;
    int tam2=0, b=0;
    p=cadena2;
    for(int i=0; i<tam; i++){
        resp=false;
        for(int a=0; a<tam2; a++){
            //cout << *(p+a) << endl;
            if(cadena[i]==(*(p+a))){
                resp=true;
            }
        }
        if(resp==false){
            b=i;
            letra=cadena[b];
           *(p+tam2)=letra;
            tam2++;
        }
    }
    cout << "Original: " << cadena << ". Sin repetidos: " << cadena2 << endl; ;
}
