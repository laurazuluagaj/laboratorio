#include <iostream>
#include <stdio.h>
#include <string.h>

using namespace std;
void fun_a(int *px, int *py);
void fun_b(int a[], int tam);
void fun_c(double *, int, double *, double *);
bool fun_d(char cad1[], char cad2[], int tam);
int fun_e(int cad[], int tam);
void fun_f(int, int *p, int *tam);
void fun_g(char cadena[], int tam);
