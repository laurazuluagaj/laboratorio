#include "Archivos.h"
#include "Codificacion.h"

void escribir_txt(string name, string data)

{
    fstream archivo(name,fstream::out | fstream::binary); //Se crea el archivo o se abre en modo escritura.
    archivo.write(data.c_str(), data.length());
    archivo.close();
}

string leer_txt(string name)
{
    long long int tam;
    string data;
    fstream archivo(name, fstream::in | fstream::ate | fstream::binary);
    if(archivo.is_open()){
        tam=archivo.tellg();
        archivo.seekg(0);
        for(long long int i=0;i<tam;i++){
            data.push_back(archivo.get());
        }
    }
    else cout << "El archivo de texto no existe." << endl;
    archivo.close();
    return data;
}

int sizeFile(string name)
{
    unsigned long long int tam;
    fstream archivo(name, fstream::in | fstream::ate | fstream::binary);
    tam=archivo.tellg();
    return tam;
}

void leerChar(string name, char *texto, unsigned long long tam)
{
    fstream archivo(name, fstream::in | fstream::ate | fstream::binary);
    if(archivo.is_open()){
        archivo.seekg(0);
        for(unsigned long long int i=0;i<tam;i++){
            texto[i]=(archivo.get());
        }
    }
    else cout << "El archivo de texto no existe." << endl;
    archivo.close();
}

void deletefile(string name)
{
    fstream archivo(name,fstream::out | fstream::binary);
    if (archivo.is_open()) archivo.close();
    remove("claveadmin.txt");
}

string addlinea(string texto, string linea)
{
    texto.push_back('\n');
    for (unsigned long long int i=0; i<linea.length();i++){
        texto.push_back(linea[i]);
    }
    return texto;
}
