#include "Decodificacion.h"
#include "Codificacion.h"

void decodificacion(string nombre, string name, int metodo, int n)
{
    if(metodo==1){
        string texto, binario, final;
        texto=leer_txt(name);
        binario=textoabin(texto);
        binario=decodebin(binario, n);
        final=bintotext(binario);
        escribir_txt(nombre, final);
     }
    else{
        char *texto, *binario;
        char *final, *binario2;
        unsigned long long tam;
        tam=sizeFile(name);
        texto=new char[tam];
        binario=new char[tam*8];
        binario2=new char[tam*8];
        final=new char[tam*8];
        leerChar(name, texto, tam);
        chartobin(texto,binario,tam);
        decodebinchar(binario, binario2, tam, n);
        bintochar(binario2, final ,tam);
        escribir_txt(nombre, final);
        delete [] texto;
        delete [] binario;
        delete [] binario2;
        delete [] final;
    }
}

string decodebin(string binario, int n)
{
    short caso=1, unos=0;
    string partido, final;
    for(unsigned long long int i=0, k=0;i<binario.length();i++){
        partido.push_back(binario[i]);
        if((k+1)*n-1==i || i==binario.length()-1){
            for(unsigned long long int i=0;i<partido.length();i++){
                switch (caso) {
                case 1:
                    if(partido[i]=='0'){
                        final.push_back('1');
                        unos++;
                    }
                    else final.push_back('0');
                    break;
                 case 2:
                    if(i%2!=0){
                        if(partido[i]=='0'){
                             final.push_back('1');
                             unos++;
                        }
                        else final.push_back('0');
                    }
                    else{
                        final.push_back(partido[i]);
                        if((partido[i])=='1') unos++;
                    }
                    break;
                case 3:
                    if((i+1)%3==0){
                        if(partido[i]=='0'){
                            final.push_back('1');
                            unos++;
                        }
                        else final.push_back('0');
                    }
                    else{
                        final.push_back(partido[i]);
                        if((partido[i])=='1') unos++;
                    }
                    break;
                }
            }
            if(unos==(n-unos)) caso=1;
            else if(unos<(n-unos)) caso=2;
            else caso=3;
            partido.clear();
            k++;
            unos=0;
        }
    }
    return final;
}

string bintotext(string binario)
{
    string texto, segmento;
    int suma=0, k=7;
    for(unsigned long long int i=0;i<binario.length();i++, k--){
            if((binario[i])=='1') suma+=pow(2,k);
            if(k==0){
                k=8;
                texto.push_back(char(suma));
                suma=0;
            }
    }
    return texto;
}

void bintochar(char *binario, char *guardar, unsigned long long int tam)
{
    int suma=0, k=7;
    tam*=8;
    for(unsigned long long int i=0, j=0;i<tam;i++, k--){
            if((binario[i])=='1') suma+=pow(2,k);
            if(k==0){
                k=8;
                guardar[j]=(char(suma));
                j++;
                suma=0;
            }
    }
}

void decodebinchar(char *binario, char *binario2, unsigned long long tam, int n)
{
    tam*=8;
    for(unsigned long long int i=0, k=n-1;i<tam;i++){
        if(i==k){
            binario2[i]=binario[i-(n-1)];
            k+=n;
        }
        else binario2[i]=binario[i+1];
    }
}
