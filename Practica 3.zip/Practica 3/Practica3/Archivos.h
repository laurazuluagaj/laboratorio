#include <iostream>
#include <fstream>
#include <string>
#include <stdlib.h>
#include <math.h>
#include<stdio.h>
#include <cmath>

using namespace std;

void escribir_txt(string name, string data);
string leer_txt(string name);
int sizeFile(string name);
void leerChar(string name, char *, unsigned long long tam);
void deletefile(string name);
string addlinea(string, string);
