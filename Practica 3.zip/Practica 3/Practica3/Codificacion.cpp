#include "Codificacion.h"
#include "Decodificacion.h"

void codificacion(string nombre, string name, int metodo, int n)
{
    if(metodo==1){
        string texto, binario, final;
        texto=leer_txt(name);
        binario=textoabin(texto);
        final=particion(binario,n);
        final=bintotext(final);
        escribir_txt(nombre, final);
     }
    else{
        char *texto, *binario;
        char *final, *guardar;
        unsigned long long tam;
        tam=sizeFile(name);
        texto=new char[tam];
        guardar=new char[tam];
        binario=new char[tam*8];
        final=new char[tam*8];
        leerChar(name, texto, tam);
        chartobin(texto,binario,tam);
        segmentar(binario, final,tam, n);
        bintochar(final, guardar, tam);
        escribir_txt(nombre, guardar);
        delete [] texto;
        delete [] guardar;
        delete [] binario;
        delete [] final;
    }
}

string textoabin(string texto)
{
    string binario;
    for(unsigned long long int i=0; i<texto.length(); i++){
        for(int j=0;j<8;j++) binario.push_back(char((((texto[i]<<j)&(0x80))/128)+48));
    }
    return binario;
}

string particion(string binario, int n)
{
    short caso=1, unos=0;
    string partido, final;
    for(unsigned long long int i=0, k=0;i<binario.length();i++){
        partido.push_back(binario[i]);
        if((k+1)*n-1==i || i==binario.length()-1){
            for(unsigned long long int i=0;i<partido.length();i++){
                switch (caso) {
                case 1:
                    if(partido[i]=='0') final.push_back('1');
                    else final.push_back('0');
                    break;
                 case 2:
                    if(i%2!=0){
                        if(partido[i]=='0') final.push_back('1');
                        else final.push_back('0');
                    }
                    else final.push_back(partido[i]);
                    break;
                case 3:
                    if((i+1)%3==0){
                        if(partido[i]=='0') final.push_back('1');
                        else final.push_back('0');
                    }
                    else final.push_back(partido[i]);
                    break;
                }
            }
            unos=contar(partido);
            if(unos==(int(partido.length())-unos)) caso=1;
            else if(unos<(int(partido.length())-unos)) caso=2;
            else caso=3;
            partido.clear();
            k++;
        }
    }
    return final;
}

int contar(string r){
    int cont=0;
    for(unsigned long long int i=0;i<r.length();i++){
        if(r[i]=='1') cont++;
    }
    return cont;
}

void chartobin(char *texto, char *binario, unsigned long long int tam)
{
    unsigned long long p=0;
    for(unsigned long long int i=0;i<tam;i++){
        for(int j=0;j<8;j++,p++){
            if(p<=(tam*8)) binario[p]=(char((((texto[i]<<j)&(0x80))/128)+48));
        }
    }
}

void segmentar(char *binario, char *final, unsigned long long tam, int n)
{
    tam*=8;
    for(unsigned long long int i=0, k=0;i<tam;i++){
        if(i==k){
            final[i]=binario[i+(n-1)];
            k+=n;
        }
        else final[i]=binario[i-1];
    }
}

void codificacion2(string nombre, string texto, int metodo, int n)
{
    string binario, final;
    binario=textoabin(texto);
    final=particion(binario,n);
    final=bintotext(final);
    escribir_txt(nombre, final);
}
