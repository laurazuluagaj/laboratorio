#include "Archivos.h"

void codificacion(string nombre, string name, int metodo, int n);
string particion(string binario, int n);
string textoabin(string texto);
int contar(string r);
void chartobin(char *, char *, unsigned long long int);
void segmentar(char *, char *, unsigned long long int, int);
void codificacion2(string nombre, string texto, int metodo, int n);
