#include "Archivos.h"

void decodificacion(string, string, int, int);
string decodebin(string, int);
string bintotext(string);
string textoabin(string texto);
void bintochar(char *, char *, unsigned long long int);
void decodebinchar(char *, char *, unsigned long long, int);
