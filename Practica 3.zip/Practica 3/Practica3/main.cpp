#include "Archivos.h"
#include "Codificacion.h"
#include "Decodificacion.h"
#include "logueo.h"

int main()
{
    int opcion;
    cout << "**************************BIENVENIDO**************************" << endl;
    cout << "Author: Laura Zuluaga Jaramillo                c.c. 1045049175" << endl;
    cout << endl;
    cout << "1-> Codificar y decodificar archivos." << endl;
    cout << "2-> Ingresar a la plataforma como administrador." << endl;
    cout << "3-> Ingresar como usuario del cajero electronico." << endl;
    cout << endl;
    cout << "Ingrese una de las opciones del menu para continuar: ";
    cin >> opcion;
    switch (opcion) {
    case 1:{
        string archivo_natural, nombre;
        int metodo, n;
        cout << "Ingrese el numero n como semilla: ";
        cin >> n;
        cout << "Ingrese el metodo de codificacion deseado: ";
        cin >> metodo;
        cout << "Ingrese 0 para codificar o 1 para decodificar: ";
        cin >> opcion;
        cout << "Ingrese el nombre del archivo de entrada: ";
        cin >> archivo_natural;
        cout << "Ingrese el nombre del archivo de salida: ";
        cin >> nombre;
        if(opcion==0) codificacion(nombre, archivo_natural, metodo, n);
        else decodificacion(nombre, archivo_natural, metodo, n);
        }
        break;
    case 2:{
        string usuario, admin, password, newuser, texto;
        cout << "Ingrese usuario administrador: ";
        cin >> usuario;
        admin=leer_txt("sudo.txt");
        if(usuario==admin){
            string pass;
            cout << "Ingrese password: ";
            cin >> pass;
            decodificacion("claveadmin.txt", "claveadmin.dat", 1, 4);
            password=leer_txt("claveadmin.txt");
            cout << password << endl;
            deletefile("claveadmin.txt");
            if (pass==password){
                cout << "Ingrese numero de cedula,clave,saldo: ";
                cin >> newuser;
                decodificacion("usuarios.txt", "usuarios.dat", 1, 4);
                texto=leer_txt("usuarios.txt");
                texto=addlinea(texto, newuser);
                escribir_txt("usuarios.txt", texto);
                codificacion2("usuarios.dat", texto, 1, 4);
                remove("usuarios.txt");
            }
            else cout << "Password incorrecto.";
        }
        else cout << "Usuario incorrecto.";
        }
        break;
    case 3:
        string usuario, pass, texto, password, saldo;
        int pos, opcion2;
        bool ingresa;
        cout << "Ingrese usuario: ";
        cin >> usuario;
        cout << "Ingrese password: ";
        cin >> pass;
        decodificacion("usuarios.txt", "usuarios.dat", 1, 4);
        texto=leer_txt("usuarios.txt");
        ingresa=user(texto, usuario, &pos);
        if (ingresa){
            password=consultPass(texto, pos, &pos);
            if (pass==password){
                saldo=consultSald(texto, pos);
                remove("usuarios.txt");
                if (saldo<"1000") cout << "No cuenta con saldo suficiente para seguir." << endl;
                else{
                    cout << "1-> Consultar saldo." << endl;
                    cout << "2-> Retirar dinero." << endl;
                    cout << endl;
                    cout << "Ingrese una de las opciones del menu para continuar: ";
                    cin >> opcion2;
                    switch (opcion2) {
                    case 1:
                        cout << "Su saldo es de " << saldo << " COP" << endl;
                        saldo=updateSald(saldo);
                        cout << "Recuerde que el costo de esta operacion es de 1000 COP." << endl;
                        texto=changeSald(texto, saldo, pos);
                        escribir_txt("usuarios.txt", texto);
                        codificacion2("usuarios.dat", texto, 1, 4);
                        remove("usuarios.txt");
                        break;
                    case 2:{
                        int retiro;
                        string newsaldo;
                        cout << "Ingrese la cantidad a retirar: ";
                        cin >> retiro;
                        newsaldo=newSaldo(saldo, retiro);
                        if (newsaldo<"0") cout << "Su saldo es insuficiente." << endl;
                        else{
                            saldo=newsaldo;
                            texto=changeSald(texto, saldo, pos);
                            escribir_txt("usuarios.txt", texto);
                            codificacion2("usuarios.dat", texto, 1, 4);
                            remove("usuarios.txt");
                        }
                    }
                        break;
                    }
                }
            }
            else cout << "Password incorrecto." << endl;
        }
        else cout << "Usuario no valido." << endl;
        break;
    }
    return 0;
}
