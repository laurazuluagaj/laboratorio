#include "logueo.h"

bool user(string texto, string cedula, int *pos)
{
    int tam, s=0;
    tam=texto.length();
    for (int i=0, j=0; i<tam; i++, j++){
        for (unsigned long long int k=0, l=i; k<cedula.length(); l++){
            if ((cedula[k])!=texto[l]){
                for(s=l; s<tam; s++){
                    if (s==tam-1) return false;
                    if (texto[s]=='\n'){
                        i=l=s;
                        k=0;
                        break;
                    }
                }
            }
            else{
                if(k==cedula.length()-1 && texto[l+1]==','){
                    if((cedula[k])==texto[l]){
                        *pos=l+2;
                        return true;
                    }
                    else return false;
                }
                k++;
            }
        }
    }
    return false;
}

string consultPass(string texto, int pos, int *p)
{
    string password;
    for(unsigned long long int i=pos; i<texto.length(); i++){
        if (texto[i]!=',') password.push_back(texto[i]);
        else{
            *p=i+1;
            break;
        }
    }
    return password;
}

string consultSald(string texto, int pos)
{
    string saldo;
    for(unsigned long long int i=pos; i<texto.length(); i++){
        if (texto[i]!='\n') saldo.push_back(texto[i]);
        else break;
    }
    return saldo;
}

string updateSald(string saldo)
{
    int exp=saldo.length()-1, newSaldo=0, numero;
    exp=pow(10,exp);
    for (unsigned long long int i=0; i<saldo.length(); i++, exp/=10){
        numero=int(saldo[i])-48;
        newSaldo+=(numero*exp);
    }
    newSaldo+=10000;
    saldo= std::to_string(newSaldo);
    return saldo;
}

string changeSald(string texto, string saldo, int pos)
{
    for(unsigned long long int i=pos, j=0; i<texto.length(); i++, j++){
        if (texto[i]!='\n'){
            if(j>=saldo.length()-1) texto.erase(texto.begin()+i);
            else texto[i]= saldo[j];
        }
        else break;
    }
    return texto;
}

string newSaldo(string saldo, int retiro)
{
    int exp=saldo.length()-1, newSaldo=0, numero;
    exp=pow(10,exp);
    for (unsigned long long int i=0; i<saldo.length(); i++, exp/=10){
        numero=int(saldo[i])-48;
        newSaldo+=(numero*exp);
    }
    newSaldo-=(retiro+1000);
    saldo= std::to_string(newSaldo);
    return saldo;
}
