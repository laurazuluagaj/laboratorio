#include "Archivos.h"

bool user(string texto, string cedula, int *);
string consultPass(string texto, int, int *);
string consultSald(string texto, int);
string updateSald(string);
string changeSald(string, string, int);
string newSaldo(string, int);
